Blockchain Basics
Project is primarily about experiencing and learning the basics of Blockchain and its fundamentals such as mining, proof of work, connecting nodes, transaction etc. Postman will help in accessing the Blockchain methods manually.
GET - http://127.0.0.1:5001/mine_block
GET - http://127.0.0.1:5001/get_chain
GET - http://127.0.0.1:5001/is_valid
GET - http://127.0.0.1:5001/replace_chain
API will look across the list of peers (nodes) added with "http//...connect_node" method in order to find the longest Blockchain and replace.
POST - http://127.0.0.1:5001/connect_node
Body (Raw) - { "nodes": ["http://xx.xx.xx.xxx:5001",.... ] } //Replace the IP address of the node to be added in local network. Each node should run this this to keep the list of nodes updated.
POST - http://127.0.0.1:5001/add_transaction
Body (Raw) - { "sender":"","receiver":"","amount":10 } // Mention the Sender, Receiver and amount.This transaction will appear in Blockchain only if a new Block is mined. There is a fixed x'tion charge along with the x'tion.
Note:Remember this is about basics of Blockchain.It is a working instance of a Blockchain in its preliminary form over a network.Consensus algorithm finds the longest chain in network and replaces it on the node. Current stage does not have Smart Contract in place as well no validation of account.
//Download the zipped file. It contains Exe file and Readme.Run exe on a windows system.